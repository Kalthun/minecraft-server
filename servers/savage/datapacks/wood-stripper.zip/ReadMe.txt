Datapack created by MandaLin
https://ko-fi.com/mandalin 
https://www.planetminecraft.com/member/mandalin/
https://modrinth.com/user/MandaLinTV
https://www.curseforge.com/members/mandalin/projects

TERMS: 
Intended usage: for single player worlds or multiplayer servers.
*Not to be re-distributed without proper credit & all of these terms met.* 
Request permission from MandaLin if wanting to use in a pack with distributor's own content added. 
Do NOT post, publish, or redistribute as your own pack. 
Not to be re-sold or used for commercial purposes.
Not to be included in any commercial or for-profit packs. 
