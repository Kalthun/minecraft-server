scoreboard objectives add heart health {"type": "object", "atlas": "gui", "sprite": "mob_effect/regeneration"}
scoreboard objectives setdisplay list heart
scoreboard objectives setdisplay below_name heart
effect give @a minecraft:regeneration 1 255 true