scoreboard objectives setdisplay below_name
playsound minecraft:ui.loom.take_result ambient @a
function h:panel