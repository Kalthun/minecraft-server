scoreboard objectives add h.isnothdep dummy
scoreboard players set @a h.isnothdep 1
scoreboard objectives add h.tempinit dummy
scoreboard players add check h.tempinit 0
execute if score init h.data matches 1 store success score status h.data run scoreboard players set check h.tempinit 1
execute if score @r ishdep matches 1 run scoreboard players set @a h.isnothdep 0
execute if score @r h.isnothdep matches 1 if score check h.tempinit matches 0 run tellraw @a ["",{"text":"Health loaded ","color":"green"},{"text":"[v2.2.0]","color":"gray"},{"text":" | to init datapack press "},{"text":"here","color":"#FF0003","click_event":{"action":"run_command","command":"/function h:start"},"hover_event":{"action":"show_text","value":"or use: /function h:start"}}]
execute if score @r ishdep matches 1 run tellraw @a ["",{"text":"Health loaded ","color":"green"},{"text":"[v2.2.0]","color":"gray"},{"text":" | loaded as dependency "}]
scoreboard objectives remove h.tempinit