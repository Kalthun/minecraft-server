title @a times 60 200 60
tellraw @a {"text":"Initialiting...","color":"green"}
scoreboard objectives add heart health {"text":"\u2764","color":"#FF0000"}
scoreboard objectives add h.data dummy
scoreboard players add init h.data 1
scoreboard objectives setdisplay list heart
scoreboard objectives setdisplay below_name heart
effect give @a minecraft:regeneration 1 255 true
tellraw @a ["",{"type": "object", "atlas": "gui", "sprite": "hud/heart/full"},{"text":" Thank you for using this datapack","color":"#FF0000"},{"text":"\n"},{"text":"Datapack initialized successfully ","color":"green"}]
tellraw @p ["",{"text":"Note:","bold":true,"color":"gray"},{"text":" use ","color":"gray"},{"text":"this","underlined":true,"color":"gray","click_event":{"action":"run_command","command":"/function h:remove"},"hover_event":{"action":"show_text","value":"/function h:remove"}},{"text":" command to properly remove the datapack. \n","color":"gray"}]
tellraw @a ["",{"text":"Note:","bold":true,"color":"gray"},{"text":" you may need to take damage to update the counter for the first time.\n","color":"gray"}]
tellraw @p ["",{"type": "object", "atlas": "gui", "sprite": "icon/info"},{"text":" Start customizing this datapack by clicking"},{"text":" here","color":"#FF0003","click_event":{"action":"run_command","command":"/function h:panelfirst"},"hover_event":{"action":"show_text","value":"You can also use: /function h:panel"}}]
playsound minecraft:ui.toast.challenge_complete ambient @p ~ ~ ~ 0.25