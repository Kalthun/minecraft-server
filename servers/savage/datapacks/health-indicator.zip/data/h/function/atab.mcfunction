scoreboard objectives setdisplay list heart
playsound minecraft:ui.loom.take_result ambient @a
function h:panel