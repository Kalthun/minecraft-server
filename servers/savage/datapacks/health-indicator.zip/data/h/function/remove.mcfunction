scoreboard objectives remove heart
scoreboard objectives remove h.isnothdep
scoreboard objectives remove h.data
tellraw @a ["",{"text":"Data pack removed successfully ","color":"#FF0000"},{"text":"[To reinstall click ","color":"green"},{"text":"here","color":"#FF0003","click_event":{"action":"run_command","command":"/function h:start"}},{"text":"]","color":"green"}]