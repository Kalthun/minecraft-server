tag @s add tnttime.fusecheck

execute if score @s tnttime.time matches 1 run team join tnttime.red
execute if score @s tnttime.time matches 2 run team join tnttime.gold
execute if score @s tnttime.time >= #3 tnttime.time run team join tnttime.green

data modify entity @s CustomNameVisible set value 1b


execute store result score @s tnttime.time run data get entity @s fuse
scoreboard players operation @s tnttime.time /= #tick tnttime.time


execute store result score @s tnttime.ms run data get entity @s fuse
scoreboard players operation @s tnttime.ms /= #ms tnttime.time
scoreboard players set @s tnttime.temp_ms 10
scoreboard players operation @s tnttime.temp_ms *= @s tnttime.time
scoreboard players operation @s tnttime.ms >< @s tnttime.temp_ms
scoreboard players operation @s tnttime.temp_ms -= @s tnttime.ms
scoreboard players operation @s tnttime.ms >< @s tnttime.temp_ms


execute store result score @s tnttime.time run data get entity @s fuse
scoreboard players operation @s tnttime.time /= #tick tnttime.time


execute in minecraft:overworld run setblock 0 -64 0 oak_sign
execute in minecraft:overworld run data modify block 0 -64 0 front_text.messages[0] set value ["",{score:{"name":"@e[type=tnt,tag=tnttime.fusecheck]",objective:"tnttime.time"}},{text:"."},{score:{name:"@e[type=tnt,tag=tnttime.fusecheck]",objective:"tnttime.ms"}}]
execute in minecraft:overworld as @s run data modify entity @s CustomName set from block 0 -64 0 front_text.messages[0]
tag @s remove tnttime.fusecheck
execute in minecraft:overworld run setblock 0 -64 0 bedrock