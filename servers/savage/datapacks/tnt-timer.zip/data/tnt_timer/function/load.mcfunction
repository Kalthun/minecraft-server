team add tnttime.red
team modify tnttime.red color red
team modify tnttime.red suffix "s"

team add tnttime.gold
team modify tnttime.gold color gold
team modify tnttime.gold suffix "s"

team add tnttime.green
team modify tnttime.green color green
team modify tnttime.green suffix "s"

scoreboard objectives add tnttime.time dummy
scoreboard objectives add tnttime.ms dummy
scoreboard objectives add tnttime.temp_ms dummy

scoreboard players set #tick tnttime.time 20
scoreboard players set #ms tnttime.time 2
scoreboard players set #3 tnttime.time 3

forceload add 0 0 0 0
setblock 0 -63 0 bedrock