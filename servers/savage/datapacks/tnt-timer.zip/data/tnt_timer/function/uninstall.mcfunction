team remove tnttime.gold
team remove tnttime.green
team remove tnttime.red

scoreboard objectives remove tnttime.ms
scoreboard objectives remove tnttime.temp_ms
scoreboard objectives remove tnttime.time

forceload remove 0 0 0 0 